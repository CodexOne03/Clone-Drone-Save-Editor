﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clone_Drone_Save_Editor
{
    class SaveFile
    {/*

        public static void Init(string fileName, TextBox output)
        {
            string path = fileName;
            output.Text = path;
            if (!File.Exists(path))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(path))
                {
                    sw.WriteLine("Hello");
                    sw.WriteLine("And");
                    sw.WriteLine("Welcome");
                }
            }

            // Open the file to read from.
            string text = File.ReadAllText(path);
            text = FindAndReplace(text, "\"NumClones\":", ",\"NumTwitchClones\":", "\"NumClones\":5");
            text = FindAndReplace(text, "\"AvailableSkillPoints\":", ",\"HumanFacts\":", "\"AvailableSkillPoints\":100");
            //text = text.Replace("\"NumClones\":" + text.ToCharArray()[text.LastIndexOf(",\"NumTwitchClones\":", text.ToCharArray().Length) - 1].ToString(), "\"NumClones\":5");
            output.Text = text;
            File.WriteAllText(path, text);
            File.Copy(path, path + ".bak", true);
        }

        public static string FindAndReplace(string text, string textToReplace, string textAfter, string replacedtext)
        {
            return text = text.Replace(textToReplace + text.ToCharArray()[text.LastIndexOf(textAfter, text.ToCharArray().Length) - 1].ToString(), replacedtext);
        }*/
    }
}
